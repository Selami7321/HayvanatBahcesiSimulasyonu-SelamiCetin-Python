from animal import Animal
import random

class Simulation:
    def __init__(self):
        self.animals = []
        self.max_steps = 1000
        self.boundary = 500
        random.seed(42)
        self.initialize_animals()

    def initialize_animals(self):
        def spawn(species, gender, count):
            for _ in range(count):
                x, y = random.uniform(0, 500), random.uniform(0, 500)
                self.animals.append(Animal(species, gender, x, y))

        spawn('sheep', 'male', 15)
        spawn('sheep', 'female', 15)
        spawn('cow', 'male', 5)
        spawn('cow', 'female', 5)
        spawn('chicken', 'female', 10)
        spawn('rooster', 'male', 10)
        spawn('wolf', 'male', 5)
        spawn('wolf', 'female', 5)
        spawn('lion', 'male', 4)
        spawn('lion', 'female', 4)
        spawn('hunter', 'none', 1)

    def simulate(self):
        for step in range(self.max_steps):
            # Hareket
            for animal in self.animals:
                if animal.alive:
                    animal.move(self.boundary)

            self.reproduce()
            self.hunt()

    def reproduce(self):
        new_animals = []
        species_groups = {}

        for a in self.animals:
            if not a.alive or a.species == 'hunter':
                continue

            key = a.species
            if key == 'rooster':
                key = 'chicken'
            species_groups.setdefault(key, {'male': [], 'female': []})
            if a.gender == 'male':
                species_groups[key]['male'].append(a)
            elif a.gender == 'female':
                species_groups[key]['female'].append(a)

        for species, group in species_groups.items():
            males = group['male']
            females = group['female']
            random.shuffle(males)
            random.shuffle(females)

            for female in females:
                for male in males:
                    if female.distance_to(male) <= 3:
                        gender = random.choice(['male', 'female'])
                        new_species = species
                        if species == 'chicken':
                            new_species = 'chicken' if gender == 'female' else 'rooster'
                        new_x = (female.x + male.x) / 2
                        new_y = (female.y + male.y) / 2
                        new_animals.append(Animal(new_species, gender, new_x, new_y))
                        break  # female only breeds once per round

        self.animals.extend(new_animals)

    def hunt(self):
        for predator in self.animals:
            if not predator.alive:
                continue

            prey_list = []
            radius = 0
            if predator.species == 'wolf':
                prey_list = ['sheep', 'chicken', 'rooster']
                radius = 4
            elif predator.species == 'lion':
                prey_list = ['cow', 'sheep']
                radius = 5
            elif predator.species == 'hunter':
                prey_list = ['sheep', 'cow', 'chicken', 'rooster', 'wolf', 'lion']
                radius = 8

            for prey in self.animals:
                if prey.alive and prey != predator and prey.species in prey_list:
                    if predator.distance_to(prey) <= radius:
                        prey.alive = False

    def get_population_count(self):
        count = {
            'sheep': 0, 'cow': 0, 'chicken': 0, 'rooster': 0,
            'wolf': 0, 'lion': 0, 'hunter': 0
        }
        for a in self.animals:
            if a.alive and a.species in count:
                count[a.species] += 1
        return count
