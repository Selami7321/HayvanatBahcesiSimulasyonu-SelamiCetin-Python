import math
import random

class Animal:
    def __init__(self, species, gender, x, y):
        self.species = species
        self.gender = gender
        self.x = x
        self.y = y
        self.alive = True

    def move(self, max_boundary=500):
        step_sizes = {
            'sheep': 2, 'cow': 2, 'wolf': 3,
            'chicken': 1, 'rooster': 1,
            'lion': 4, 'hunter': 1
        }
        step = step_sizes.get(self.species, 1)
        angle = random.uniform(0, 2 * math.pi)
        dx = step * math.cos(angle)
        dy = step * math.sin(angle)
        self.x = max(0, min(self.x + dx, max_boundary))
        self.y = max(0, min(self.y + dy, max_boundary))

    def distance_to(self, other):
        return math.hypot(self.x - other.x, self.y - other.y)
