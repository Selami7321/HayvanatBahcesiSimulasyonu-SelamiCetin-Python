from simulation import Simulation
import time

def main():
    start = time.time()
    sim = Simulation()
    sim.simulate()
    end = time.time()

    counts = sim.get_population_count()
    print("\n📊 1000 Adım Sonunda Hayvan Popülasyonu:")
    for species, count in counts.items():
        print(f"{species.capitalize():<10}: {count}")
    print(f"\n⏱️ Simülasyon Süresi: {end - start:.2f} saniye")
    print(f"Toplam Hayvan Sayısı: {sum(counts.values())}")

if __name__ == "__main__":
    main()
